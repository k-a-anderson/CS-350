#
# Milestone1.py - This is the Python code template that will be used
# for Milestone 1, demonstrating the use of PWM to fade an LED in and
# out.
#
# This code works with the test circuit that was built for Assignment 1-4.
#
# ------------------------------------------------------------------
# Change History
# ------------------------------------------------------------------
# Version   |   Description
# ------------------------------------------------------------------
#    1          Initial Development
# ------------------------------------------------------------------

# Load the GPIO interface from the Raspberry Pi Python Module
# The GPIO interface will be available through the GPIO object
import RPi.GPIO as GPIO

# Load the time module so that we can utilize the sleep method to
# inject a pause into our operation
import time

# Setup the GPIO interface
#
# 1. Turn off warnings for now - they can be useful for debugging more
#    complex code.
# 2. Tell the GPIO library we are using Broadcom pin-numbering.
# 3. Configure GPIO line 18 for output.
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.OUT)

# Configure a PWM instance on GPIO line 18 with a frequency of 60Hz
pwm18 = GPIO.PWM(18, 60)

# Start the PWM instance on GPIO line 18 with 0% duty cycle
pwm18.start(0)

#
# Configure the loop variable so that we can exit cleanly when the user
# issues a keyboard interrupt (CTRL-C)

#
repeat = True

while repeat:
    try:
        # Loop from 0 to 100 in increments of 5
        # This gradually increases the brightness of the LED
        for dutyCycle in range(0, 101, 5):
            # Update the PWM duty cycle
            pwm18.ChangeDutyCycle(dutyCycle)

            # Pause for 1/10th of a second
            time.sleep(0.1)

        # Loop from 100 back down to 0 in increments of -5
        # This gradually decreases the brightness of the LED
        for dutyCycle in range(100, -1, -5):
            # Update the PWM duty cycle
            pwm18.ChangeDutyCycle(dutyCycle)

            # Pause for 1/10th of a second
            time.sleep(0.1)

    except KeyboardInterrupt:

        # Stop the PWM instance on GPIO line 18
        print('Stopping PWM and Cleaning Up')

        # Stop PWM output
        pwm18.stop()

        # Reset GPIO pins
        GPIO.cleanup()

        # Exit the loop
        repeat = False

# Cleanup the GPIO pins used in this application and exit
GPIO.cleanup()